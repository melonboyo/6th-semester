import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class SDFtoIMG {
	
	public static class Point {
		
		public Point(double x, double y) {
			this.x = x;
			this.y = y;
		}
		
		public Point() {
			this(0, 0);
		}
		
		double x, y;
		
		public void rotate(double r) {
			
			double nx = Math.cos(r) * x - Math.sin(r) * y;
			double ny = Math.sin(r) * x + Math.cos(r) * y;
			
			x = nx;
			y = ny;
			
		}
		
		public void translate(double x, double y) {
			this.x += x;
			this.y += y;
		}
		
		@Override
		public String toString() {
			return "( " + x + ", " + y + ")";
		}
	}
	
	public static class Rectangle {
		Point[] points;
		
		public double minx() {
			double x = Double.MAX_VALUE;
			for(int i = 0; i < points.length; i++)
				if(points[i].x < x)
					x = points[i].x;
			return x;
		}
		
		public double maxx() {
			double x = Double.MIN_VALUE;
			for(int i = 0; i < points.length; i++)
				if(points[i].x > x)
					x = points[i].x;
			return x;
		}
		
		public double miny() {
			double y = Double.MAX_VALUE;
			for(int i = 0; i < points.length; i++)
				if(points[i].y < y)
					y = points[i].y;
			return y;
		}
		
		public double maxy() {
			double y = Double.MIN_VALUE;
			for(int i = 0; i < points.length; i++)
				if(points[i].y > y)
					y = points[i].y;
			return y;
		}
	}
	
	public static Node getNodeByName(Node n, String name) {
		
		NodeList ns = n.getChildNodes();
		for(int i = 0; i < ns.getLength(); i++) {
			if(ns.item(i).getNodeName().equals(name))
				return ns.item(i);
		}
		
		return null;
	}
	
	public static void main(String[] args) throws Exception {
		
		if(args.length != 1)
			return;
		
		File f = new File(args[0]);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(f);

		Node mNode = getNodeByName(doc.getFirstChild(), "model");
		
		NodeList linksList = mNode.getChildNodes();
		ArrayList<Rectangle> rectangles = new ArrayList<>();
		
		for(int i = 0; i < linksList.getLength(); i++) {
			
			Node link = linksList.item(i);
			if(!link.getNodeName().contentEquals("link"))
				continue;
			
			System.out.println("LINK: " + link.getNodeName());
			Node collBoxNode = getNodeByName(link, "collision");
			collBoxNode = getNodeByName(collBoxNode, "geometry");
			collBoxNode = getNodeByName(collBoxNode, "box");
			collBoxNode = getNodeByName(collBoxNode, "size").getFirstChild();
			double[] vals = new double[3];
			String[] split = collBoxNode.getNodeValue().split(" ");
			for(int j = 0; j < vals.length; j++)
				vals[j] = Double.parseDouble(split[j]);
			
			Node poseNode = getNodeByName(link, "pose");
			
			double[] pose = new double[6];
			split = poseNode.getFirstChild().getNodeValue().split(" ");
			for(int j = 0; j < pose.length; j++)
				pose[j] = Double.parseDouble(split[j]);
			
			Rectangle r = new Rectangle();
			
			double x = pose[0];
			double y = pose[1];
			double rot = pose[5];
			double w = vals[0];
			double h = vals[1];
			
			Point[] points = new Point[] {
					new Point(-w/2, -h/2),
					new Point( w/2, -h/2),
					new Point( w/2,  h/2),
					new Point(-w/2,  h/2)
			};
			
			System.out.println(link.getAttributes().getNamedItem("name"));
			
			for(Point p : points) {
				p.rotate(rot);
				p.translate(x, y);
				System.out.println(p);
			}
			
			r.points = points;
			
			System.out.println("????");
			rectangles.add(r);
		}
		
		// Meters per pixel
		double scale = 1/50.0;
		
		double minx = Double.MAX_VALUE, maxx = Double.MIN_VALUE;
		double miny = Double.MAX_VALUE, maxy = Double.MIN_VALUE;
		for(Rectangle r : rectangles) {
			System.out.println(minx);
			if(r.maxx() > maxx)
				maxx = r.maxx();
			if(r.minx() < minx)
				minx = r.minx();
			
			if(r.maxy() > maxy)
				maxy = r.maxy();
			if(r.miny() < miny)
				miny = r.miny();
		}

		int iw = (int) Math.ceil((maxx - minx) / scale);
		int ih = (int) Math.ceil((maxy - miny) / scale);
		
		int xoff = (int) (minx / scale);
		int yoff = (int) (miny / scale);
		
		iw += 50;
		ih += 50;
		
		xoff -= 25;
		yoff -= 25;
		
		BufferedImage img = new BufferedImage(iw, ih, BufferedImage.TYPE_INT_ARGB);
		
		Graphics2D g = (Graphics2D) img.getGraphics();
		
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, iw, ih);
		
		g.setColor(Color.BLACK);
		
		for(Rectangle r : rectangles) {
			
			int[] xpoints = new int[r.points.length];
			int[] ypoints = new int[r.points.length];
			
			for(int i = 0; i < r.points.length; i++) {
				xpoints[i] = ((int) (r.points[i].x / scale)) - xoff;
				ypoints[i] = ih - (((int) (r.points[i].y / scale)) - yoff);
			}
			
			g.fillPolygon(xpoints, ypoints, r.points.length);
			
		}
		
		ImageIO.write(img, "PNG", new FileOutputStream(args[0] + "(" + xoff + "," + yoff + ").png"));
		
	}
	
}
